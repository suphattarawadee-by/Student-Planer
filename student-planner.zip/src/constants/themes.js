export const THEMES = {
  cyberpunk: {
    name: 'Cyberpunk Neon',
    bg: 'bg-slate-950',
    card: 'bg-slate-900/80 border-cyan-500/30',
    accent: 'text-cyan-400',
    btnPrimary: 'bg-gradient-to-r from-cyan-500 to-fuchsia-500 text-white shadow-lg shadow-cyan-500/20 hover:opacity-95',
    tag: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40',
    badge: 'border-fuchsia-500/50 text-fuchsia-300 bg-fuchsia-950/40'
  },
  pastel: {
    name: 'Pastel Dream',
    bg: 'bg-gradient-to-br from-indigo-950 via-purple-950 to-pink-950',
    card: 'bg-indigo-900/40 border-pink-400/30 backdrop-blur-md',
    accent: 'text-pink-300',
    btnPrimary: 'bg-gradient-to-r from-pink-400 to-indigo-400 text-slate-950 font-semibold shadow-lg shadow-pink-500/20 hover:opacity-95',
    tag: 'bg-pink-500/20 text-pink-200 border-pink-400/40',
    badge: 'border-indigo-400/50 text-indigo-200 bg-indigo-950/40'
  },
  matcha: {
    name: 'Matcha Minimal',
    bg: 'bg-[#0f1715]',
    card: 'bg-[#152420]/80 border-emerald-500/30',
    accent: 'text-emerald-400',
    btnPrimary: 'bg-emerald-500 text-slate-950 font-semibold shadow-lg shadow-emerald-500/20 hover:bg-emerald-400',
    tag: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
    badge: 'border-teal-500/50 text-teal-300 bg-teal-950/40'
  },
  sunset: {
    name: 'Solar Sunset',
    bg: 'bg-slate-950',
    card: 'bg-slate-900/90 border-amber-500/30',
    accent: 'text-amber-400',
    btnPrimary: 'bg-gradient-to-r from-amber-500 to-rose-500 text-white shadow-lg shadow-amber-500/20 hover:opacity-95',
    tag: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
    badge: 'border-rose-500/50 text-rose-300 bg-rose-950/40'
  }
};

export const AVATAR_STYLES = [
  { id: 'bottts', name: 'หุ่นยนต์ไซเบอร์ (Bottts)' },
  { id: 'adventurer', name: 'นักผจญภัย (Adventurer)' },
  { id: 'lorelei', name: 'อะนิเมะมินิมอล (Lorelei)' },
  { id: 'fun-emoji', name: 'อิโมจิสุดกวน (Fun Emoji)' },
];

export function getAvatarUrl(seed, style = 'bottts') {
  return `https://api.dicebear.com/7.x/${style}/svg?seed=${encodeURIComponent(seed || 'student')}`;
}

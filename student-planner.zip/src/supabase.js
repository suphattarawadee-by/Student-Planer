import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://qiirydpgjzmxwpexydkq.supabase.co'
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFpaXJ5ZHBnanpteHdwZXh5ZGtxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTE3MDI0NjAsImV4cCI6MjEwNzI3ODQ2MH0.cavfGanhp5hi0mGVSQoIYAms5FRr6QOZKhKjtgKZ2s0'

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

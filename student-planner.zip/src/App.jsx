import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Login from './components/Login';
import PlannerView from './components/PlannerView';
import LeaderboardView from './components/LeaderboardView';
import LabAuditView from './components/LabAuditView';
import TeacherDashboard from './components/TeacherDashboard';
import StudentImportModal from './components/StudentImportModal';
import { supabase } from './supabase';

export default function App() {
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState('planner'); // 'planner' | 'leaderboard' | 'lab' | 'teacher'
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);

  // Mock State สำหรับให้นักเรียน 45 คน ใช้งานได้ทันทีแบบ Interactive
  const [assignments, setAssignments] = useState([
    {
      id: 'task-1',
      title: 'ออกแบบพวงกุญแจ 3 มิติ (3D Keychain)',
      description: 'ออกแบบพวงกุญแจที่มีชื่อของตนเอง โดยใช้เทคนิคการเจาะรู (Hole) และการรวมกลุ่ม (Group) ใน Tinkercad',
      objectives: '1. สร้างโมเดลเรขาคณิตพื้นฐานได้ 2. รวมกลุ่มวัตถุและเจาะรูเพื่อร้อยห่วงได้ถูกต้อง',
      example_model_url: 'https://www.tinkercad.com/embed/bL7G88t8v0f',
      due_datetime: new Date(Date.now() + 86400000 * 5).toISOString(), // อีก 5 วัน
    },
    {
      id: 'task-2',
      title: 'ออกแบบบ้านประหยัดพลังงานทรงโมเดิร์น',
      description: 'สร้างบ้าน 3 มิติ พร้อมแผงโซลาร์เซลล์บนหลังคา และช่องระบายลมธรรมชาติ',
      objectives: '1. เข้าใจสัดส่วนโครงสร้างทางสถาปัตยกรรม 2. สามารถจัดวาง Object ที่มีความซับซ้อนได้',
      example_model_url: 'https://www.tinkercad.com/embed/bL7G88t8v0f',
      due_datetime: new Date(Date.now() + 86400000 * 12).toISOString(), // อีก 12 วัน
    }
  ]);

  // สร้างรายชื่อนักเรียนตัวอย่าง 45 คน (จำลองข้อมูลห้องเรียนโรงเรียนบัวใหญ่)
  const [students, setStudents] = useState(() => {
    return Array.from({ length: 45 }, (_, i) => {
      const id = (6701 + i).toString();
      return {
        id: `std-${id}`,
        student_id: id,
        full_name: `นักเรียนเลขที่ ${i + 1}`,
        avatar_seed: `std-${id}`,
        total_score: Math.floor(15 + Math.random() * 25)
      };
    });
  });

  const [submissions, setSubmissions] = useState([
    {
      id: 'sub-1',
      student_id: 'std-6705',
      student_name: 'นักเรียนเลขที่ 5',
      assignment_title: 'ออกแบบพวงกุญแจ 3 มิติ (3D Keychain)',
      submission_type: 'draft',
      tinkercad_url: 'https://www.tinkercad.com/things/sample-keychain',
      notes: 'ลองทำฟอนต์ตัวหนาแล้วครับ อยากให้ครูช่วยดูความหนาของฐานรอง',
      computer_no: 5,
      submitted_at: new Date(Date.now() - 3600000 * 2).toISOString(),
      planning_score: 2,
      process_score: 2,
      late_deduction: 0,
      rubric_score: 0,
      total_score: 4,
      status: 'pending'
    },
    {
      id: 'sub-2',
      student_id: 'std-6712',
      student_name: 'นักเรียนเลขที่ 12',
      assignment_title: 'ออกแบบพวงกุญแจ 3 มิติ (3D Keychain)',
      submission_type: 'final',
      tinkercad_url: 'https://www.tinkercad.com/things/sample-keychain',
      notes: 'งานเสร็จสมบูรณ์แล้วครับ',
      computer_no: 12,
      submitted_at: new Date(Date.now() - 3600000 * 5).toISOString(),
      planning_score: 1.5,
      process_score: 1.5,
      late_deduction: 0,
      rubric_score: 9.5,
      total_score: 12.5,
      status: 'graded',
      teacher_feedback: 'จัดวางสัดส่วนตัวหนังสือได้สวยงามมาก ผ่านเกณฑ์ยอดเยี่ยม!'
    }
  ]);

  const [behaviorLogs, setBehaviorLogs] = useState([
    {
      id: 'b-1',
      student_id: 'std-6701',
      student_name: 'นักเรียนเลขที่ 1',
      type: 'good_deed',
      category: '🤝 ช่วยเพื่อนสอนคำสั่ง Tinkercad',
      score_change: 1,
      created_at: new Date(Date.now() - 1800000).toISOString()
    }
  ]);

  const [issues, setIssues] = useState([
    {
      id: 'iss-1',
      computer_no: 5,
      issue_type: 'virus',
      description: 'พบโฟลเดอร์แปลกปลอมในไดรฟ์ D และหน้าจอมีโฆษณาเด้ง',
      status: 'open',
      created_at: new Date(Date.now() - 7200000).toISOString()
    }
  ]);

  // Handler: เมื่อนักเรียนบันทึกแผนงาน
  const handleSavePlan = (planData) => {
    alert(`บันทึกแผนงานแล้ว! แผนของคุณคือ: ${planData.plan_type === 'early' ? 'ส่งก่อนเวลา (+2 แต้ม)' : planData.plan_type === 'on_time' ? 'ส่งตรงเวลา (+1.5 แต้ม)' : 'ขอส่งเลท (+1 แต้ม)'}`);
  };

  // Handler: เมื่อนักเรียนส่งงาน Tinkercad
  const handleSubmitWork = (subData) => {
    const newSub = {
      id: `sub-${Date.now()}`,
      student_id: user.student_id,
      student_name: user.full_name,
      assignment_title: assignments.find((a) => a.id === subData.assignment_id)?.title || 'งานออกแบบ 3D',
      submission_type: subData.submission_type,
      tinkercad_url: subData.tinkercad_url,
      notes: subData.notes,
      computer_no: subData.computer_no,
      submitted_at: new Date().toISOString(),
      planning_score: 2,
      process_score: subData.submission_type === 'draft' ? 2 : 1.5,
      late_deduction: 0,
      rubric_score: 0,
      total_score: subData.submission_type === 'draft' ? 4 : 3.5,
      status: 'pending'
    };

    setSubmissions([newSub, ...submissions]);
    alert('ส่งงาน Tinkercad 3D สำเร็จ! ครูสุภัทรวดีได้รับแจ้งเตือนแล้ว 🚀');
  };

  // Handler: ให้คะแนนความดี / ตัดคะแนนพฤติกรรม
  const handleAddBehavior = (data) => {
    const newLog = {
      id: `b-${Date.now()}`,
      ...data,
      created_at: new Date().toISOString()
    };
    setBehaviorLogs([newLog, ...behaviorLogs]);

    // อัปเดตคะแนนรวมของนักเรียนคนนั้น
    setStudents((prev) =>
      prev.map((s) => {
        if (s.id === data.student_id) {
          return {
            ...s,
            total_score: (s.total_score || 0) + data.score_change
          };
        }
        return s;
      })
    );
  };

  // Handler: รายงานปัญหาเครื่องคอมพิวเตอร์
  const handleReportIssue = (issueData) => {
    const newIss = {
      id: `iss-${Date.now()}`,
      ...issueData,
      status: 'open',
      created_at: new Date().toISOString()
    };
    setIssues([newIss, ...issues]);
  };

  // Handler: ครูสร้างภาระงานใหม่
  const handleCreateAssignment = (taskData) => {
    const newTask = {
      id: `task-${Date.now()}`,
      ...taskData
    };
    setAssignments([newTask, ...assignments]);
  };

  // Handler: ครูให้คะแนนงานและส่งฟีดแบค
  const handleGradeSubmission = ({ submission_id, rubric_score, teacher_feedback }) => {
    setSubmissions((prev) =>
      prev.map((s) => {
        if (s.id === submission_id) {
          const total = (s.planning_score || 0) + (s.process_score || 0) - (s.late_deduction || 0) + rubric_score;
          return {
            ...s,
            rubric_score,
            total_score: total,
            teacher_feedback,
            status: 'graded'
          };
        }
        return s;
      })
    );
  };

  // ถ้ายังไม่ล็อกอิน ให้แสดงหน้า Login
  if (!user) {
    return <Login onLogin={(loggedInUser) => setUser(loggedInUser)} />;
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      <Navbar
        user={user}
        onLogout={() => setUser(null)}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        unreadCount={user.role === 'teacher' ? submissions.filter((s) => s.status === 'pending').length : 1}
      />

      <main className="flex-1 pb-16">
        {user.role === 'teacher' && activeTab === 'planner' ? (
          <TeacherDashboard
            user={user}
            assignments={assignments}
            submissions={submissions}
            onCreateAssignment={handleCreateAssignment}
            onGradeSubmission={handleGradeSubmission}
            onOpenImportModal={() => setIsImportModalOpen(true)}
          />
        ) : activeTab === 'planner' ? (
          <PlannerView
            user={user}
            assignments={assignments}
            submissions={submissions}
            onSavePlan={handleSavePlan}
            onSubmitWork={handleSubmitWork}
          />
        ) : null}

        {activeTab === 'leaderboard' && (
          <LeaderboardView
            user={user}
            students={students}
            behaviorLogs={behaviorLogs}
            onAddBehavior={handleAddBehavior}
          />
        )}

        {activeTab === 'lab' && (
          <LabAuditView
            user={user}
            submissions={submissions}
            issues={issues}
            onReportIssue={handleReportIssue}
          />
        )}
      </main>

      <StudentImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        onImportStudents={(newStudents) => {
          setStudents((prev) => [...newStudents, ...prev]);
        }}
      />

      <footer className="border-t border-slate-900 bg-slate-950 py-6 text-center text-xs text-slate-500">
        <p className="font-medium text-slate-400">
          Student Planner ครูสุภัทรวดี • โรงเรียนบัวใหญ่
        </p>
        <p className="text-[11px] text-slate-600 mt-1">
          องค์การบริหารส่วนจังหวัดนครราชสีมา • รองรับการเรียนการสอนรายวิชาคอมพิวเตอร์ & 3D Tinkercad
        </p>
      </footer>
    </div>
  );
}

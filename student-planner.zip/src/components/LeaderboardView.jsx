import React, { useState } from 'react';
import { Trophy, Heart, AlertTriangle, Plus, Minus, Sparkles, Medal } from 'lucide-react';
import { getAvatarUrl } from '../constants/themes';
import confetti from 'canvas-confetti';

export default function LeaderboardView({ user, students = [], behaviorLogs = [], onAddBehavior }) {
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [customReason, setCustomReason] = useState('');
  const [customScore, setCustomScore] = useState(1);

  // Quick Deed & Penalty presets
  const GOOD_DEEDS = [
    { label: '🤝 ช่วยเพื่อนทำงาน', score: 1 },
    { label: '🧑‍🏫 ช่วยครู/งานห้องเรียน', score: 1 },
    { label: '🙋 ตอบคำถามในคาบ', score: 1 },
    { label: '💡 ความคิดสร้างสรรค์ยอดเยี่ยม', score: 2 },
    { label: '🖥️ ดูแลคอมพิวเตอร์เรียบร้อย', score: 1 },
  ];

  const PENALTIES = [
    { label: '👔 แต่งกายไม่เรียบร้อย', score: -1 },
    { label: '🗣️ พูดไม่สุภาพ', score: -1 },
    { label: '🧹 ไม่รักษาความสะอาดโต๊ะคอมฯ', score: -1 },
    { label: '📢 ส่งเสียงดังรบกวนเพื่อน', score: -1 },
    { label: '🎮 เล่นเกมนอกเวลาที่กำหนด', score: -2 },
  ];

  const handleQuickAction = (student, item, isPositive) => {
    onAddBehavior({
      student_id: student.id,
      student_name: student.full_name,
      type: isPositive ? 'good_deed' : 'discipline',
      category: item.label,
      score_change: item.score
    });

    if (isPositive) {
      confetti({ particleCount: 30, spread: 50 });
    }
  };

  // Sort students by total score descending
  const sortedStudents = [...students].sort((a, b) => (b.total_score || 0) - (a.total_score || 0));

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      
      {/* Header */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-fuchsia-500/10 border border-fuchsia-500/30 text-fuchsia-300 text-xs font-semibold mb-2">
          <Trophy className="w-3.5 h-3.5" /> ทำเนียบคนเก่ง & แต้มความดีประจำห้อง
        </div>
        <h2 className="text-2xl font-bold text-white">
          Hall of Fame: นักเรียนโรงเรียนบัวใหญ่
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          ระบบรวมคะแนนชิ้นงาน Tinkercad 3D + คะแนนการวางแผน + แต้มจิตพิสัยในคาบเรียนครูสุภัทรวดี
        </p>
      </div>

      {/* Top 3 Podium Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        {sortedStudents.slice(0, 3).map((student, index) => {
          const rankColors = [
            'border-amber-400/60 bg-gradient-to-b from-amber-500/10 to-slate-900', // 1st Gold
            'border-slate-300/60 bg-gradient-to-b from-slate-400/10 to-slate-900', // 2nd Silver
            'border-amber-700/60 bg-gradient-to-b from-amber-800/10 to-slate-900', // 3rd Bronze
          ];
          const rankIcons = ['👑 ที่ 1 เหรียญทอง', '🥈 ที่ 2 เหรียญเงิน', '🥉 ที่ 3 เหรียญทองแดง'];

          return (
            <div
              key={student.id}
              className={`p-6 rounded-3xl border ${rankColors[index]} text-center relative overflow-hidden shadow-xl`}
            >
              <div className="text-xs font-bold text-amber-300 mb-3">{rankIcons[index]}</div>
              <img
                src={getAvatarUrl(student.avatar_seed || student.student_id)}
                alt="Avatar"
                className="w-20 h-20 rounded-full mx-auto mb-3 border-2 border-white/20 bg-slate-950 p-1 shadow-lg"
              />
              <h3 className="font-bold text-base text-white">{student.full_name}</h3>
              <p className="text-xs text-slate-400">รหัส: {student.student_id}</p>
              
              <div className="mt-4 inline-block px-4 py-1.5 rounded-full bg-slate-950/80 border border-white/10">
                <span className="text-xl font-black text-cyan-400">{student.total_score || 0}</span>
                <span className="text-xs text-slate-400 ml-1">คะแนนสะสม</span>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* All Students List (Rankings) */}
        <div className="lg:col-span-2 space-y-3">
          <h3 className="text-sm font-semibold text-slate-300 mb-2">
            อันดับคะแนนรวมทั้งห้อง ({sortedStudents.length} คน)
          </h3>

          <div className="space-y-2">
            {sortedStudents.map((student, idx) => (
              <div
                key={student.id}
                className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-slate-700 transition"
              >
                <div className="flex items-center gap-3">
                  <span className={`w-6 text-center font-bold text-xs ${idx < 3 ? 'text-amber-400' : 'text-slate-500'}`}>
                    #{idx + 1}
                  </span>
                  <img
                    src={getAvatarUrl(student.avatar_seed || student.student_id)}
                    alt="Avatar"
                    className="w-10 h-10 rounded-full bg-slate-950 border border-slate-700 p-0.5"
                  />
                  <div>
                    <h4 className="text-xs font-bold text-white">{student.full_name}</h4>
                    <p className="text-[10px] text-slate-400">เลขประจำตัว: {student.student_id}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <span className="text-sm font-extrabold text-cyan-400">{student.total_score || 0}</span>
                    <span className="text-[10px] text-slate-500 block">แต้มรวม</span>
                  </div>

                  {/* Teacher Quick Karma Buttons */}
                  {user?.role === 'teacher' && (
                    <div className="flex items-center gap-1 pl-2 border-l border-slate-800">
                      <button
                        onClick={() => handleQuickAction(student, { label: '🌟 โบนัสตอบคำถาม', score: 1 }, true)}
                        className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 text-xs"
                        title="ให้ +1 แต้มความดี"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleQuickAction(student, { label: '⚠️ ไม่รักษาความสะอาด/เสียงดัง', score: -1 }, false)}
                        className="p-1.5 rounded-lg bg-rose-500/20 text-rose-300 hover:bg-rose-500/30 text-xs"
                        title="ตัด -1 แต้มพฤติกรรม"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Live Classroom Karma Activity Feed */}
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5">
            <h3 className="text-xs font-bold text-slate-300 mb-3 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-fuchsia-400" /> ฟีดบันทึกความดี & วินัยในคาบ
            </h3>
            
            <div className="space-y-2.5 max-h-[480px] overflow-y-auto pr-1">
              {behaviorLogs.length === 0 ? (
                <p className="text-xs text-slate-500 text-center py-6">ยังไม่มีประวัติในคาบนี้</p>
              ) : (
                behaviorLogs.map((log) => (
                  <div
                    key={log.id}
                    className={`p-3 rounded-xl border text-xs ${
                      log.type === 'good_deed'
                        ? 'bg-emerald-950/30 border-emerald-500/30 text-emerald-200'
                        : 'bg-rose-950/30 border-rose-500/30 text-rose-200'
                    }`}
                  >
                    <div className="flex justify-between font-semibold">
                      <span>{log.student_name}</span>
                      <span>{log.score_change > 0 ? `+${log.score_change}` : log.score_change} แต้ม</span>
                    </div>
                    <p className="text-[11px] opacity-80 mt-0.5">{log.category}</p>
                    <span className="text-[10px] opacity-60 block mt-1">
                      {new Date(log.created_at).toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit' })} น.
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}

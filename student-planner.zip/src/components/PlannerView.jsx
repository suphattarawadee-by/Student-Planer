import React, { useState } from 'react';
import { Calendar, Clock, Sparkles, Send, Box, AlertCircle, Award, CheckCircle2, ChevronRight, MessageSquare } from 'lucide-react';
import confetti from 'canvas-confetti';

export default function PlannerView({ user, assignments = [], submissions = [], onSavePlan, onSubmitWork }) {
  const [selectedTask, setSelectedTask] = useState(assignments[0] || null);
  const [planType, setPlanType] = useState('on_time'); // early, on_time, late
  const [plannedDate, setPlannedDate] = useState('');
  
  // Submission Form State
  const [tinkercadUrl, setTinkercadUrl] = useState('');
  const [computerNo, setComputerNo] = useState(1);
  const [submissionNotes, setSubmissionNotes] = useState('');
  const [submissionType, setSubmissionType] = useState('final'); // draft, final

  const handlePlanCommit = (e) => {
    e.preventDefault();
    if (!selectedTask || !plannedDate) return;
    onSavePlan({
      assignment_id: selectedTask.id,
      planned_date: plannedDate,
      plan_type: planType
    });
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.8 }
    });
  };

  const handleSubmitTinkercad = (e) => {
    e.preventDefault();
    if (!selectedTask || !tinkercadUrl.trim()) return;

    // คำนวณเวลาว่าส่งก่อน 30 นาทีหรือไม่สำหรับ Draft
    const now = new Date();
    const deadline = new Date(selectedTask.due_datetime);
    const diffMinutes = (deadline - now) / (1000 * 60);

    let isDraftEligible = false;
    if (submissionType === 'draft') {
      if (diffMinutes < 30) {
        alert('⚠️ การส่งแบบขอคำแนะนำเพื่อพัฒนา (Draft) ต้องส่งก่อนหมดเวลาอย่างน้อย 30 นาทีครับ');
        return;
      }
      isDraftEligible = true;
    }

    onSubmitWork({
      assignment_id: selectedTask.id,
      submission_type: submissionType,
      tinkercad_url: tinkercadUrl.trim(),
      notes: submissionNotes,
      computer_no: parseInt(computerNo, 10),
      isDraftEligible
    });

    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 }
    });

    setTinkercadUrl('');
    setSubmissionNotes('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-cyan-950/60 via-slate-900 to-fuchsia-950/60 border border-slate-800 rounded-3xl p-6 sm:p-8 mb-8 relative overflow-hidden">
        <div className="relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-semibold mb-3">
            <Sparkles className="w-3.5 h-3.5" /> แผนการเรียนรู้ & ภาระงานรายเดือน
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-white">
            สวัสดี {user?.full_name} วางแผนคว้าคะแนนเต็มกันเถอะ! 🎯
          </h2>
          <p className="text-sm text-slate-400 mt-1 max-w-2xl leading-relaxed">
            งานทุกชิ้นมีคะแนนการวางแผน <span className="text-cyan-300 font-semibold">+2 คะแนน</span> (ส่งก่อนเวลาได้ +2, ตรงเวลาได้ +1.5, ขอเลทได้ +1 แต่หักความรับผิดชอบ 2) และส่ง Draft ล่วงหน้า 30 นาที ได้เพิ่มอีก <span className="text-fuchsia-300 font-semibold">+2 คะแนน</span>!
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left Col: Task List */}
        <div className="space-y-4">
          <h3 className="text-sm font-semibold text-slate-300 flex items-center gap-2 uppercase tracking-wider">
            <Calendar className="w-4 h-4 text-cyan-400" /> รายการภาระงานเดือนนี้
          </h3>
          
          <div className="space-y-3">
            {assignments.map((task) => {
              const isSelected = selectedTask?.id === task.id;
              const deadline = new Date(task.due_datetime);
              return (
                <div
                  key={task.id}
                  onClick={() => setSelectedTask(task)}
                  className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-slate-900 border-cyan-500/60 shadow-lg shadow-cyan-500/10'
                      : 'bg-slate-900/50 border-slate-800 hover:border-slate-700 hover:bg-slate-900/80'
                  }`}
                >
                  <div className="flex justify-between items-start gap-2">
                    <h4 className="font-semibold text-sm text-slate-200">{task.title}</h4>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700 whitespace-nowrap">
                      Tinkercad 3D
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1 line-clamp-2">{task.description}</p>
                  
                  <div className="flex items-center gap-2 mt-3 text-[11px] text-slate-500">
                    <Clock className="w-3.5 h-3.5 text-rose-400" />
                    <span>กำหนดส่ง: {deadline.toLocaleDateString('th-TH')} {deadline.toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit' })} น.</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Col: Details, Commitment & Tinkercad Submit */}
        {selectedTask && (
          <div className="lg:col-span-2 space-y-6">
            
            {/* Task Objectives & Reference Box */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-4 mb-4">
                <div>
                  <h3 className="text-lg font-bold text-white">{selectedTask.title}</h3>
                  <p className="text-xs text-cyan-400 mt-0.5">ครูสุภัทรวดี โรงเรียนบัวใหญ่</p>
                </div>
                <div className="text-xs px-3 py-1 rounded-xl bg-slate-800 border border-slate-700 text-slate-300">
                  เดดไลน์: {new Date(selectedTask.due_datetime).toLocaleString('th-TH')}
                </div>
              </div>

              {/* Objectives */}
              <div className="mb-4">
                <h5 className="text-xs font-semibold text-slate-300 mb-1">🎯 จุดประสงค์การเรียนรู้:</h5>
                <p className="text-xs text-slate-400 leading-relaxed bg-slate-950 p-3 rounded-xl border border-slate-800/80">
                  {selectedTask.objectives || 'สร้างและออกแบบชิ้นงานโมเดล 3 มิติด้วย Tinkercad ตามเกณฑ์'}
                </p>
              </div>

              {/* Teacher's Reference 3D or Image */}
              {selectedTask.example_model_url && (
                <div className="mb-4">
                  <h5 className="text-xs font-semibold text-slate-300 mb-2 flex items-center gap-1.5">
                    <Box className="w-4 h-4 text-cyan-400" /> ตัวอย่างผลงานโมเดล 3D จากครู:
                  </h5>
                  <div className="w-full h-64 bg-slate-950 rounded-2xl border border-cyan-500/30 overflow-hidden relative">
                    <iframe
                      src={selectedTask.example_model_url}
                      className="w-full h-full border-0"
                      title="Tinkercad 3D Model Preview"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Step 1: Commitment Planning (คะแนนการวางแผน) */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6">
              <h4 className="text-sm font-bold text-white mb-1 flex items-center gap-2">
                <Award className="w-4 h-4 text-cyan-400" /> สเต็ปที่ 1: วางแผนส่งงาน (รับคะแนนวางแผนเต็ม +2)
              </h4>
              <p className="text-xs text-slate-400 mb-4">
                เลือกรูปแบบและวันที่ตั้งใจจะส่งงาน เพื่อฝึกทักษะการบริหารเวลา (Time Management)
              </p>

              <form onSubmit={handlePlanCommit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div
                    onClick={() => setPlanType('early')}
                    className={`p-3.5 rounded-2xl border cursor-pointer transition text-left ${
                      planType === 'early'
                        ? 'bg-cyan-500/20 border-cyan-500 text-cyan-200'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="text-xs font-bold flex items-center gap-1">🚀 ส่งก่อนเวลา</div>
                    <div className="text-[11px] text-cyan-300 font-semibold mt-1">+2.0 คะแนน</div>
                    <div className="text-[10px] text-slate-500 mt-1">ส่งทันก่อนเดดไลน์</div>
                  </div>

                  <div
                    onClick={() => setPlanType('on_time')}
                    className={`p-3.5 rounded-2xl border cursor-pointer transition text-left ${
                      planType === 'on_time'
                        ? 'bg-indigo-500/20 border-indigo-500 text-indigo-200'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="text-xs font-bold flex items-center gap-1">🎯 ส่งตรงเวลา</div>
                    <div className="text-[11px] text-indigo-300 font-semibold mt-1">+1.5 คะแนน</div>
                    <div className="text-[10px] text-slate-500 mt-1">ส่งในวันเดดไลน์</div>
                  </div>

                  <div
                    onClick={() => setPlanType('late')}
                    className={`p-3.5 rounded-2xl border cursor-pointer transition text-left ${
                      planType === 'late'
                        ? 'bg-rose-500/20 border-rose-500 text-rose-200'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="text-xs font-bold flex items-center gap-1">⏳ ขอส่งเลท</div>
                    <div className="text-[11px] text-rose-400 font-semibold mt-1">+1.0 คะแนน</div>
                    <div className="text-[10px] text-rose-400/80 mt-1">หักความรับผิดชอบ 2 แต้ม</div>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-3 items-center">
                  <div className="w-full sm:flex-1">
                    <input
                      type="date"
                      required
                      value={plannedDate}
                      onChange={(e) => setPlannedDate(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full sm:w-auto px-6 py-2.5 bg-gradient-to-r from-cyan-500 to-indigo-500 text-white rounded-xl text-xs font-semibold shadow-md shadow-cyan-500/20 hover:opacity-95"
                  >
                    บันทึกแผนงานของฉัน ✨
                  </button>
                </div>
              </form>
            </div>

            {/* Step 2: Submission Form (Tinkercad Link & Computer No) */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6">
              <h4 className="text-sm font-bold text-white mb-1 flex items-center gap-2">
                <Send className="w-4 h-4 text-fuchsia-400" /> สเต็ปที่ 2: ส่งงาน Tinkercad 3D & ระบุเครื่องคอมฯ
              </h4>
              <p className="text-xs text-slate-400 mb-4">
                เลือกรูปแบบการส่งว่าต้องการให้ครูแนะนำเพื่อพัฒนาก่อน หรือส่งตรวจจริงเลย
              </p>

              <form onSubmit={handleSubmitTinkercad} className="space-y-4">
                
                {/* Draft vs Final Options */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div
                    onClick={() => setSubmissionType('draft')}
                    className={`p-4 rounded-2xl border cursor-pointer transition text-left ${
                      submissionType === 'draft'
                        ? 'bg-amber-500/20 border-amber-500 text-amber-200 shadow-sm'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold">🛠️ ส่งให้ครูดูเพื่อพัฒนา (Draft)</span>
                      <span className="text-[11px] font-bold text-amber-300">+2.0 แต้ม</span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1">
                      ต้องส่งก่อนหมดเวลาอย่างน้อย 30 นาที ครูจะให้คำแนะนำเพื่อนำไปแก้ไขก่อนตรวจจริง
                    </p>
                  </div>

                  <div
                    onClick={() => setSubmissionType('final')}
                    className={`p-4 rounded-2xl border cursor-pointer transition text-left ${
                      submissionType === 'final'
                        ? 'bg-emerald-500/20 border-emerald-500 text-emerald-200 shadow-sm'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold">📝 ส่งตรวจจริงเลย (Final)</span>
                      <span className="text-[11px] font-bold text-emerald-300">+1.5 แต้ม</span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1">
                      ส่งชิ้นงานสมบูรณ์เพื่อประเมินคะแนนตามเกณฑ์ Rubrics ทันที
                    </p>
                  </div>
                </div>

                {/* Computer Number Select (1 - 45) */}
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">
                    🖥️ เครื่องคอมพิวเตอร์ที่นั่งใช้งาน (ห้องปฏิบัติการคอมพิวเตอร์)
                  </label>
                  <select
                    value={computerNo}
                    onChange={(e) => setComputerNo(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                  >
                    {Array.from({ length: 45 }, (_, i) => i + 1).map((num) => (
                      <option key={num} value={num}>
                        เครื่องคอมพิวเตอร์หมายเลข {num}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Tinkercad Share Link */}
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">
                    🔗 ลิงก์ชิ้นงาน Tinkercad 3D (Share Link / View Link)
                  </label>
                  <input
                    type="url"
                    required
                    placeholder="https://www.tinkercad.com/things/..."
                    value={tinkercadUrl}
                    onChange={(e) => setTinkercadUrl(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-cyan-500"
                  />
                </div>

                {/* Notes */}
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">
                    💡 แนวคิดในการออกแบบ / สิ่งที่อยากบอกครู
                  </label>
                  <textarea
                    rows={2}
                    placeholder="เช่น ออกแบบเป็นยานอวกาศ เน้นเรื่องเหลี่ยมมุม..."
                    value={submissionNotes}
                    onChange={(e) => setSubmissionNotes(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-xs text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-cyan-500"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 px-4 bg-gradient-to-r from-fuchsia-500 to-cyan-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-fuchsia-500/20 hover:opacity-95 transition"
                >
                  ยืนยันการส่งงานชิ้นนี้ 🚀
                </button>
              </form>
            </div>

          </div>
        )}

      </div>
    </div>
  );
}

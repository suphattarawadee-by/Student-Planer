import React, { useState } from 'react';
import { Laptop, AlertCircle, CheckCircle, Search, ShieldAlert, History, User } from 'lucide-react';
import { getAvatarUrl } from '../constants/themes';

export default function LabAuditView({ user, submissions = [], issues = [], onReportIssue }) {
  const [selectedComputer, setSelectedComputer] = useState(5);
  const [reportType, setReportType] = useState('virus');
  const [reportDescription, setReportDescription] = useState('');

  // รวมประวัติการใช้งานของเครื่องที่เลือก
  const historyForSelectedComp = submissions
    .filter((s) => s.computer_no === selectedComputer)
    .sort((a, b) => new Date(b.submitted_at) - new Date(a.submitted_at));

  // ปัญหาที่เคยถูกบันทึกไว้ในเครื่องนี้
  const issuesForSelectedComp = issues.filter((i) => i.computer_no === selectedComputer);

  const handleReport = (e) => {
    e.preventDefault();
    if (!reportDescription.trim()) return;

    onReportIssue({
      computer_no: selectedComputer,
      issue_type: reportType,
      description: reportDescription.trim()
    });

    setReportDescription('');
    alert(`บันทึกรายงานปัญหาสำหรับเครื่องที่ ${selectedComputer} เรียบร้อยแล้ว`);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-semibold mb-2">
            <Laptop className="w-3.5 h-3.5" /> ตรวจสอบห้องปฏิบัติการคอมพิวเตอร์ (45 เครื่อง)
          </div>
          <h2 className="text-2xl font-bold text-white">
            แผนผังและการใช้งานคอมพิวเตอร์ 1-45
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            บันทึกประวัติการนั่งใช้งานย้อนหลัง และตรวจสอบปัญหาเครื่องชำรุด/ไวรัสลง ประจำห้องเรียนครูสุภัทรวดี
          </p>
        </div>
      </div>

      {/* 45 Computers Grid Map */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 mb-8">
        <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-4 flex items-center justify-between">
          <span>คลิกเลือกหมายเลขเครื่องเพื่อดูประวัติ (1 - 45)</span>
          <span className="text-[11px] font-normal text-slate-400">
            🟢 เครื่องปกติ | 🔴 เครื่องมีรายงานปัญหา
          </span>
        </h3>

        <div className="grid grid-cols-5 sm:grid-cols-9 md:grid-cols-15 gap-2">
          {Array.from({ length: 45 }, (_, i) => i + 1).map((compNo) => {
            const hasIssue = issues.some((iss) => iss.computer_no === compNo && iss.status === 'open');
            const isSelected = selectedComputer === compNo;

            return (
              <button
                key={compNo}
                onClick={() => setSelectedComputer(compNo)}
                className={`h-12 rounded-xl flex flex-col items-center justify-center font-bold text-xs transition-all relative ${
                  isSelected
                    ? 'ring-2 ring-cyan-400 bg-cyan-950 text-cyan-300 shadow-lg shadow-cyan-500/20'
                    : hasIssue
                    ? 'bg-rose-950/60 border border-rose-500/50 text-rose-300 hover:bg-rose-900/60'
                    : 'bg-slate-950 border border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-900'
                }`}
              >
                <span>#{compNo}</span>
                <span className="text-[9px] opacity-70">
                  {hasIssue ? '⚠️ พัง' : 'พร้อม'}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Computer Audit Detail */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left 2 Cols: Usage Timeline (จับตัวคนใช้งาน) */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-4">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <History className="w-4 h-4 text-cyan-400" /> ไทม์ไลน์ผู้ใช้งาน: เครื่องคอมพิวเตอร์ #{selectedComputer}
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  รายชื่อนักเรียนที่ใช้งานเครื่องนี้ตามประวัติการส่งงาน
                </p>
              </div>
              <span className="text-xs px-3 py-1 rounded-full bg-cyan-950 border border-cyan-500/30 text-cyan-300 font-bold">
                ใช้งานรวม {historyForSelectedComp.length} ครั้ง
              </span>
            </div>

            <div className="space-y-3">
              {historyForSelectedComp.length === 0 ? (
                <div className="text-center py-10 text-xs text-slate-500">
                  ยังไม่มีประวัติการส่งงานจากเครื่องหมายเลข #{selectedComputer}
                </div>
              ) : (
                historyForSelectedComp.map((record) => (
                  <div
                    key={record.id}
                    className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between"
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={getAvatarUrl(record.student_name || 'student')}
                        alt="Avatar"
                        className="w-10 h-10 rounded-full bg-slate-900 border border-slate-700 p-0.5"
                      />
                      <div>
                        <h4 className="text-xs font-bold text-white">{record.student_name || 'นักเรียน'}</h4>
                        <p className="text-[11px] text-cyan-400">งาน: {record.assignment_title}</p>
                        <span className="text-[10px] text-slate-500">
                          ส่งเมื่อ: {new Date(record.submitted_at).toLocaleString('th-TH')}
                        </span>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${
                        record.submission_type === 'draft'
                          ? 'bg-amber-950 border border-amber-500/40 text-amber-300'
                          : 'bg-emerald-950 border border-emerald-500/40 text-emerald-300'
                      }`}>
                        {record.submission_type === 'draft' ? 'Draft Review' : 'Final Submit'}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Right Col: Incident & Issue Reporter */}
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6">
            <h3 className="text-sm font-bold text-white mb-2 flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-rose-400" /> รายงานปัญหาเครื่อง #{selectedComputer}
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              บันทึกกรณีเครื่องพัง ไวรัสลง หรืออุปกรณ์ชำรุด เพื่อตรวจสอบย้อนหลัง
            </p>

            <form onSubmit={handleReport} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  ประเภทปัญหาที่พบ:
                </label>
                <select
                  value={reportType}
                  onChange={(e) => setReportType(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-rose-500"
                >
                  <option value="virus">🦠 ไวรัสลง / ไฟล์ระบบถูกลบ</option>
                  <option value="hardware_broken">💥 อุปกรณ์ชำรุด (เมาส์/คีย์บอร์ด/จอ)</option>
                  <option value="dirt">🧹 โต๊ะสกปรก / มีเศษขยะ</option>
                  <option value="other">❓ อื่นๆ</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  รายละเอียดปัญหา:
                </label>
                <textarea
                  required
                  rows={3}
                  placeholder="เช่น เมาส์คลิกขวาไม่ติด มีไฟล์แปลกปลอมบน Desktop..."
                  value={reportDescription}
                  onChange={(e) => setReportDescription(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-rose-500"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 px-4 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold shadow-md shadow-rose-600/20 transition"
              >
                บันทึกเหตุการณ์ลงระบบ ⚠️
              </button>
            </form>
          </div>

          {/* Issue list on this computer */}
          {issuesForSelectedComp.length > 0 && (
            <div className="bg-rose-950/20 border border-rose-500/30 rounded-3xl p-5">
              <h4 className="text-xs font-bold text-rose-300 mb-2">ประวัติปัญหาที่แจ้งในเครื่องนี้:</h4>
              <div className="space-y-2">
                {issuesForSelectedComp.map((iss) => (
                  <div key={iss.id} className="text-xs bg-slate-950/80 p-2.5 rounded-xl border border-rose-500/20">
                    <div className="font-semibold text-rose-300">{iss.issue_type}</div>
                    <p className="text-slate-400 mt-0.5">{iss.description}</p>
                    <span className="text-[10px] text-slate-500 mt-1 block">
                      {new Date(iss.created_at).toLocaleString('th-TH')}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

      </div>

    </div>
  );
}

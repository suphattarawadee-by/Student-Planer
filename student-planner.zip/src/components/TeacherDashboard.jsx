import React, { useState } from 'react';
import { Plus, CheckSquare, MessageSquare, ExternalLink, Box, Bell, Award, Users } from 'lucide-react';
import { getAvatarUrl } from '../constants/themes';

export default function TeacherDashboard({
  user,
  assignments = [],
  submissions = [],
  onCreateAssignment,
  onGradeSubmission,
  onOpenImportModal
}) {
  const [activeTab, setActiveTab] = useState('grading'); // 'grading' | 'create_task'
  const [selectedSub, setSelectedSub] = useState(null);

  // New Assignment Form State
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newObjectives, setNewObjectives] = useState('');
  const [newExampleModelUrl, setNewExampleModelUrl] = useState('');
  const [newDueDate, setNewDueDate] = useState('');
  const [newDueTime, setNewDueTime] = useState('23:59');

  // Grading State
  const [rubricScore, setRubricScore] = useState(10);
  const [feedback, setFeedback] = useState('');

  const handleCreateTask = (e) => {
    e.preventDefault();
    if (!newTitle.trim() || !newDueDate) return;

    onCreateAssignment({
      title: newTitle.trim(),
      description: newDesc,
      objectives: newObjectives,
      example_model_url: newExampleModelUrl.trim(),
      due_datetime: `${newDueDate}T${newDueTime}:00`
    });

    setNewTitle('');
    setNewDesc('');
    setNewObjectives('');
    setNewExampleModelUrl('');
    alert('สร้างภาระงานใหม่เรียบร้อยแล้ว!');
    setActiveTab('grading');
  };

  const handleGrade = (e) => {
    e.preventDefault();
    if (!selectedSub) return;

    onGradeSubmission({
      submission_id: selectedSub.id,
      rubric_score: parseFloat(rubricScore),
      teacher_feedback: feedback
    });

    alert('บันทึกคะแนนและส่งฟีดแบคเรียบร้อย!');
    setSelectedSub(null);
    setFeedback('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
          <span className="text-xs px-3 py-1 rounded-full bg-fuchsia-500/10 border border-fuchsia-500/30 text-fuchsia-300 font-semibold">
            ระบบจัดการสำหรับครูผู้สอน
          </span>
          <h2 className="text-2xl font-bold text-white mt-2">
            แผงควบคุมครูสุภัทรวดี (โรงเรียนบัวใหญ่)
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            ตรวจงาน Tinkercad 3D, ให้ฟีดแบคแบบ Realtime, และสร้างภาระงานรายเดือน
          </p>
        </div>

        {/* Action Toggle */}
        <div className="flex flex-wrap items-center gap-2 bg-slate-900 p-1.5 rounded-2xl border border-slate-800">
          <button
            onClick={() => onOpenImportModal()}
            className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30 transition flex items-center gap-1.5"
          >
            <Users className="w-3.5 h-3.5" /> นำเข้านักเรียน (Excel)
          </button>
          <button
            onClick={() => setActiveTab('grading')}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition ${
              activeTab === 'grading'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            คิวตรวจงาน ({submissions.filter((s) => s.status === 'pending').length})
          </button>
          <button
            onClick={() => setActiveTab('create_task')}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition flex items-center gap-1.5 ${
              activeTab === 'create_task'
                ? 'bg-fuchsia-500/20 text-fuchsia-300 border border-fuchsia-500/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Plus className="w-3.5 h-3.5" /> สั่งงานใหม่
          </button>
        </div>
      </div>

      {/* Tab 1: Create Task */}
      {activeTab === 'create_task' && (
        <div className="max-w-2xl mx-auto bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8">
          <h3 className="text-lg font-bold text-white mb-2">กำหนดภาระงานใหม่ให้นักเรียน 45 คน</h3>
          <p className="text-xs text-slate-400 mb-6">
            ระบุชื่องาน จุดประสงค์ และตัวอย่างโมเดล 3D จาก Tinkercad ให้นักเรียนหมุนดูเป็นแนวทาง
          </p>

          <form onSubmit={handleCreateTask} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">ชื่องาน / ภาระงาน:</label>
              <input
                type="text"
                required
                placeholder="เช่น ออกแบบบ้านประหยัดพลังงาน 3D"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">คำอธิบายงาน:</label>
              <textarea
                rows={2}
                placeholder="รายละเอียดเงื่อนไขของงาน..."
                value={newDesc}
                onChange={(e) => setNewDesc(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">จุดประสงค์การเรียนรู้ (Objectives):</label>
              <textarea
                rows={2}
                placeholder="1. สามารถใช้คำสั่ง Group และ Hole ใน Tinkercad ได้..."
                value={newObjectives}
                onChange={(e) => setNewObjectives(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                🔗 ลิงก์โมเดล Tinkercad 3D ตัวอย่าง (ถ้ามี ให้นักเรียนหมุนดู):
              </label>
              <input
                type="url"
                placeholder="https://www.tinkercad.com/things/..."
                value={newExampleModelUrl}
                onChange={(e) => setNewExampleModelUrl(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">วันกำหนดส่ง (Deadline Date):</label>
                <input
                  type="date"
                  required
                  value={newDueDate}
                  onChange={(e) => setNewDueDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">เวลา (Deadline Time):</label>
                <input
                  type="time"
                  required
                  value={newDueTime}
                  onChange={(e) => setNewDueTime(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 px-4 bg-gradient-to-r from-fuchsia-500 to-indigo-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-fuchsia-500/20 hover:opacity-95 transition"
            >
              ประกาศภาระงานนี้ลงปฏิทินนักเรียน 🚀
            </button>
          </form>
        </div>
      )}

      {/* Tab 2: Grading Queue */}
      {activeTab === 'grading' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Submissions List */}
          <div className="lg:col-span-1 space-y-3">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
              รายการที่นักเรียนส่งเข้ามา ({submissions.length} รายการ)
            </h3>

            <div className="space-y-2.5">
              {submissions.map((sub) => {
                const isSelected = selectedSub?.id === sub.id;
                return (
                  <div
                    key={sub.id}
                    onClick={() => {
                      setSelectedSub(sub);
                      setRubricScore(sub.rubric_score || 10);
                      setFeedback(sub.teacher_feedback || '');
                    }}
                    className={`p-4 rounded-2xl border cursor-pointer transition ${
                      isSelected
                        ? 'bg-slate-900 border-cyan-500 shadow-lg shadow-cyan-500/10'
                        : 'bg-slate-900/50 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                        sub.submission_type === 'draft'
                          ? 'bg-amber-950 border border-amber-500/40 text-amber-300'
                          : 'bg-emerald-950 border border-emerald-500/40 text-emerald-300'
                      }`}>
                        {sub.submission_type === 'draft' ? '🟡 ขอตรวจเพื่อพัฒนา (Draft)' : '🟢 ส่งตรวจจริง (Final)'}
                      </span>
                      <span className="text-[10px] text-cyan-400 font-bold">
                        🖥️ เครื่อง #{sub.computer_no}
                      </span>
                    </div>

                    <h4 className="text-xs font-bold text-white">{sub.student_name}</h4>
                    <p className="text-[11px] text-slate-400 mt-0.5">{sub.assignment_title}</p>
                    
                    <div className="flex items-center justify-between text-[10px] text-slate-500 mt-2">
                      <span>ส่ง: {new Date(sub.submitted_at).toLocaleTimeString('th-TH')} น.</span>
                      <span className="font-semibold text-slate-300">{sub.status === 'graded' ? 'ตรวจแล้ว ✅' : 'รอตรวจ ⏳'}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Grading & 3D View Panel */}
          <div className="lg:col-span-2">
            {selectedSub ? (
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6">
                
                {/* Header */}
                <div className="flex justify-between items-start border-b border-slate-800 pb-4">
                  <div>
                    <h3 className="text-base font-bold text-white">ตรวจงาน: {selectedSub.student_name}</h3>
                    <p className="text-xs text-slate-400 mt-0.5">ภาระงาน: {selectedSub.assignment_title}</p>
                    <span className="inline-block mt-1 text-[11px] px-2.5 py-0.5 rounded-md bg-slate-800 text-cyan-300">
                      นั่งทำที่คอมพิวเตอร์หมายเลข #{selectedSub.computer_no}
                    </span>
                  </div>
                  <a
                    href={selectedSub.tinkercad_url}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-xs font-semibold hover:bg-cyan-500/30"
                  >
                    เปิดใน Tinkercad <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>

                {/* Interactive 3D Viewer or Link */}
                <div className="w-full h-80 bg-slate-950 rounded-2xl border border-cyan-500/30 overflow-hidden relative flex items-center justify-center">
                  <iframe
                    src={selectedSub.tinkercad_url}
                    className="w-full h-full border-0"
                    title="Student 3D Design Preview"
                  />
                </div>

                {/* Student's Design Notes */}
                {selectedSub.notes && (
                  <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800">
                    <span className="text-xs font-bold text-slate-300 block mb-1">💡 บันทึกแนวคิดจากนักเรียน:</span>
                    <p className="text-xs text-slate-400 leading-relaxed">{selectedSub.notes}</p>
                  </div>
                )}

                {/* Score Breakdown summary */}
                <div className="grid grid-cols-3 gap-3 p-3 bg-slate-950 rounded-2xl border border-slate-800 text-center">
                  <div>
                    <span className="text-[10px] text-slate-500 block">คะแนนวางแผน</span>
                    <span className="text-xs font-bold text-cyan-400">+{selectedSub.planning_score || 0}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block">คะแนนกระบวนการ</span>
                    <span className="text-xs font-bold text-fuchsia-400">+{selectedSub.process_score || 0}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block">หักเลท</span>
                    <span className="text-xs font-bold text-rose-400">{selectedSub.late_deduction || 0}</span>
                  </div>
                </div>

                {/* Grading Form */}
                <form onSubmit={handleGrade} className="space-y-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      ⭐ คะแนนเนื้องานตาม Rubrics (เต็ม 10 หรือ 20):
                    </label>
                    <input
                      type="number"
                      required
                      step="0.5"
                      min="0"
                      value={rubricScore}
                      onChange={(e) => setRubricScore(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      💬 คำแนะนำ / ฟีดแบคถึงนักเรียน (เพื่อนำไปพัฒนา):
                    </label>
                    <textarea
                      required
                      rows={3}
                      placeholder="เช่น โมเดลมีความสมดุลดีแล้ว ลองปรับความสูงของเสาให้ได้สัดส่วนอีกนิด..."
                      value={feedback}
                      onChange={(e) => setFeedback(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 px-4 bg-gradient-to-r from-cyan-500 to-indigo-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-cyan-500/20 hover:opacity-95 transition"
                  >
                    ส่งฟีดแบคและบันทึกคะแนนให้นักเรียน ✅
                  </button>
                </form>

              </div>
            ) : (
              <div className="h-full flex items-center justify-center p-12 bg-slate-900/30 border border-dashed border-slate-800 rounded-3xl text-center text-slate-500 text-xs">
                คลิกเลือกรายการส่งงานทางซ้ายเพื่อเปิดดูโมเดล 3D และเริ่มให้คะแนน
              </div>
            )}
          </div>

        </div>
      )}

    </div>
  );
}

import React, { useState } from 'react';
import { Sparkles, Shield, User, KeyRound, School } from 'lucide-react';
import { getAvatarUrl } from '../constants/themes';

export default function Login({ onLogin }) {
  const [studentId, setStudentId] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('student'); // 'student' | 'teacher'
  const [avatarSeed, setAvatarSeed] = useState('ninja');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!studentId.trim()) return;

    // จำลองหรือล็อกอินผ่านระบบ
    const userData = {
      student_id: studentId.trim(),
      full_name: role === 'teacher' ? 'ครูสุภัทรวดี' : `นักเรียน (${studentId})`,
      role: role,
      avatar_seed: role === 'teacher' ? 'teacher-pro' : (avatarSeed || studentId),
      theme_preference: 'cyberpunk'
    };
    onLogin(userData);
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col justify-center items-center px-4 py-12 relative overflow-hidden">
      {/* Background Neon Orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-fuchsia-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Main Card */}
      <div className="w-full max-w-md bg-slate-900/90 border border-slate-800 backdrop-blur-xl rounded-3xl p-8 shadow-2xl relative z-10">
        
        {/* Header with School Branding */}
        <div className="text-center mb-8">
          <div className="inline-flex p-3 rounded-2xl bg-gradient-to-tr from-cyan-500/20 via-indigo-500/20 to-fuchsia-500/20 border border-cyan-500/30 mb-4 shadow-inner">
            <School className="w-8 h-8 text-cyan-400" />
          </div>
          <h1 className="text-2xl font-bold bg-gradient-to-r from-cyan-400 via-indigo-300 to-fuchsia-400 bg-clip-text text-transparent">
            Student Planner
          </h1>
          <p className="text-sm font-medium text-slate-300 mt-1">
            ครูสุภัทรวดี โรงเรียนบัวใหญ่
          </p>
          <span className="inline-block mt-1 text-[11px] px-3 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700">
            องค์การบริหารส่วนจังหวัดนครราชสีมา
          </span>
        </div>

        {/* Role Toggle */}
        <div className="grid grid-cols-2 gap-2 p-1 bg-slate-950 rounded-2xl border border-slate-800 mb-6">
          <button
            type="button"
            onClick={() => setRole('student')}
            className={`py-2 text-xs font-semibold rounded-xl transition-all ${
              role === 'student'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            นักเรียน (45 คน)
          </button>
          <button
            type="button"
            onClick={() => {
              setRole('teacher');
              setStudentId('teacher');
              setPassword('1234');
            }}
            className={`py-2 text-xs font-semibold rounded-xl transition-all ${
              role === 'teacher'
                ? 'bg-fuchsia-500/20 text-fuchsia-300 border border-fuchsia-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            ครูสุภัทรวดี (Admin)
          </button>
        </div>

        {/* Avatar Preview for Student */}
        {role === 'student' && (
          <div className="flex flex-col items-center mb-6">
            <div className="relative group cursor-pointer" onClick={() => setAvatarSeed(Math.random().toString(36).substring(7))}>
              <img
                src={getAvatarUrl(avatarSeed)}
                alt="Avatar"
                className="w-16 h-16 rounded-full bg-slate-950 border-2 border-cyan-400/50 p-1 shadow-lg shadow-cyan-500/20"
              />
              <span className="absolute bottom-0 right-0 bg-cyan-500 text-[10px] text-slate-950 font-bold px-1.5 py-0.5 rounded-full shadow">
                สุ่ม
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1">คลิกที่รูปเพื่อสุ่ม Avatar ตัวโปรด ✨</p>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              {role === 'teacher' ? 'บัญชีผู้สอน' : 'รหัสนักเรียน (เลขประจำตัว)'}
            </label>
            <div className="relative">
              <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                required
                value={studentId}
                onChange={(e) => setStudentId(e.target.value)}
                placeholder={role === 'teacher' ? 'teacher' : 'เช่น 6701, 6702, ...'}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-sm text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-cyan-500/60 focus:ring-1 focus:ring-cyan-500/50 transition"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              รหัสผ่าน (เข้าสู่ระบบ)
            </label>
            <div className="relative">
              <KeyRound className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="กรอกรหัสผ่าน"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-sm text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-cyan-500/60 focus:ring-1 focus:ring-cyan-500/50 transition"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full mt-2 py-3 px-4 rounded-xl font-medium text-sm bg-gradient-to-r from-cyan-500 via-indigo-500 to-fuchsia-500 text-white shadow-lg shadow-cyan-500/25 hover:opacity-95 transition-all active:scale-[0.98]"
          >
            {role === 'teacher' ? 'เข้าสู่ระบบครูผู้สอน' : 'เข้าสู่ระบบเริ่มวางแผนงาน 🚀'}
          </button>
        </form>

        <div className="mt-6 text-center">
          <p className="text-[11px] text-slate-500">
            ระบบจัดเก็บข้อมูลภาระงาน & ตรวจสอบห้องปฏิบัติการคอมพิวเตอร์
          </p>
        </div>

      </div>
    </div>
  );
}

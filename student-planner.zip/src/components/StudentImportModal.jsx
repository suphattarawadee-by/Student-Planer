import React, { useState } from 'react';
import { Plus, Users, UserPlus, FileSpreadsheet, ExternalLink, Check, Trash2, X } from 'lucide-react';
import { getAvatarUrl } from '../constants/themes';

export default function StudentImportModal({ isOpen, onClose, onImportStudents }) {
  const [importMode, setImportMode] = useState('bulk_text'); // 'bulk_text' | 'manual'
  const [bulkText, setBulkText] = useState('');
  const [studentId, setStudentId] = useState('');
  const [studentName, setStudentName] = useState('');

  if (!isOpen) return null;

  // ตัวอย่างข้อความสำหรับให้ครูกดลอง
  const sampleData = `6701, ด.ช.กิตติศักดิ์ ใจดี
6702, ด.ญ.กัญญาณัฐ สุขสม
6703, ด.ช.ณัฐภัทร วงศ์ษา
6704, ด.ญ.ธนภรณ์ รัตนโชติ
6705, ด.ช.ธีรพัฒน์ บุญญา`;

  const handleBulkImport = (e) => {
    e.preventDefault();
    if (!bulkText.trim()) return;

    // แยกข้อมูลทีละบรรทัด (รองรับทั้ง comma, tab หรือเว้นวรรค)
    const lines = bulkText.split('\n');
    const newStudents = [];

    lines.forEach((line, index) => {
      const trimmed = line.trim();
      if (!trimmed) return;

      let id = '';
      let name = '';

      if (trimmed.includes(',')) {
        const parts = trimmed.split(',');
        id = parts[0].trim();
        name = parts.slice(1).join(',').trim();
      } else if (trimmed.includes('\t')) {
        const parts = trimmed.split('\t');
        id = parts[0].trim();
        name = parts.slice(1).join(' ').trim();
      } else {
        const parts = trimmed.split(/\s+/);
        id = parts[0].trim();
        name = parts.slice(1).join(' ').trim();
      }

      if (id) {
        newStudents.push({
          id: `std-${id}`,
          student_id: id,
          full_name: name || `นักเรียน (${id})`,
          avatar_seed: `std-${id}`,
          total_score: 0
        });
      }
    });

    if (newStudents.length > 0) {
      onImportStudents(newStudents);
      alert(`นำเข้ารายชื่อนักเรียนสำเร็จทั้งหมด ${newStudents.length} คน! 🎉`);
      setBulkText('');
      onClose();
    }
  };

  const handleSingleAdd = (e) => {
    e.preventDefault();
    if (!studentId.trim() || !studentName.trim()) return;

    onImportStudents([{
      id: `std-${studentId.trim()}`,
      student_id: studentId.trim(),
      full_name: studentName.trim(),
      avatar_seed: `std-${studentId.trim()}`,
      total_score: 0
    }]);

    setStudentId('');
    setStudentName('');
    alert('เพิ่มนักเรียนเรียบร้อย!');
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-xl p-6 sm:p-8 shadow-2xl relative">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 rounded-2xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">
              นำเข้ารายชื่อนักเรียน (Student Importer)
            </h3>
            <p className="text-xs text-slate-400">
              สำหรับห้องเรียนครูสุภัทรวดี โรงเรียนบัวใหญ่
            </p>
          </div>
        </div>

        {/* Mode Selector */}
        <div className="grid grid-cols-2 gap-2 p-1 bg-slate-950 rounded-2xl border border-slate-800 mb-6">
          <button
            type="button"
            onClick={() => setImportMode('bulk_text')}
            className={`py-2 text-xs font-semibold rounded-xl transition ${
              importMode === 'bulk_text'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            📋 วางจาก Excel / รายชื่อทั้งห้อง (45 คน)
          </button>
          <button
            type="button"
            onClick={() => setImportMode('manual')}
            className={`py-2 text-xs font-semibold rounded-xl transition ${
              importMode === 'manual'
                ? 'bg-fuchsia-500/20 text-fuchsia-300 border border-fuchsia-500/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            ➕ เพิ่มทีละคน
          </button>
        </div>

        {/* Bulk Import Mode */}
        {importMode === 'bulk_text' && (
          <form onSubmit={handleBulkImport} className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-1.5">
                <label className="text-xs font-medium text-slate-300">
                  คัดลอกรายชื่อจาก Excel มาวางที่นี่ (รูปแบบ: รหัสนักเรียน, ชื่อ-นามสกุล):
                </label>
                <button
                  type="button"
                  onClick={() => setBulkText(sampleData)}
                  className="text-[11px] text-cyan-400 hover:underline"
                >
                  ลองใส่ข้อมูลตัวอย่าง
                </button>
              </div>
              <textarea
                rows={7}
                required
                value={bulkText}
                onChange={(e) => setBulkText(e.target.value)}
                placeholder="ตัวอย่างการวาง:&#10;6701, ด.ช.กิตติศักดิ์ ใจดี&#10;6702, ด.ญ.กัญญาณัฐ สุขสม&#10;6703, ด.ช.ณัฐภัทร วงศ์ษา..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-slate-200 font-mono focus:outline-none focus:border-cyan-500"
              />
              <p className="text-[11px] text-slate-500 mt-1">
                💡 สามารถก๊อปปี้ 2 คอลัมน์ (รหัส และ ชื่อ) จากโปรแกรม Microsoft Excel แล้วกดวางได้ทันที
              </p>
            </div>

            <button
              type="submit"
              className="w-full py-3 px-4 bg-gradient-to-r from-cyan-500 to-indigo-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-cyan-500/20 hover:opacity-95"
            >
              นำเข้ารายชื่อทั้งหมดลงระบบ 🚀
            </button>
          </form>
        )}

        {/* Manual Add Single Mode */}
        {importMode === 'manual' && (
          <form onSubmit={handleSingleAdd} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                เลขประจำตัวนักเรียน:
              </label>
              <input
                type="text"
                required
                placeholder="เช่น 6701"
                value={studentId}
                onChange={(e) => setStudentId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                ชื่อ-นามสกุล:
              </label>
              <input
                type="text"
                required
                placeholder="เช่น ด.ช.สมชาย สายลม"
                value={studentName}
                onChange={(e) => setStudentName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 px-4 bg-gradient-to-r from-fuchsia-500 to-cyan-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-fuchsia-500/20 hover:opacity-95"
            >
              บันทึกนักเรียนคนนี้ ➕
            </button>
          </form>
        )}

      </div>
    </div>
  );
}
